function [J3,eta0,eta1,p_cap0t,p_cap1t,sigma1,sigma2,P0,P1] = WR_GKIT(K10,K11,K20,K21,R0t,R1t,h)
format long;
landa0=exp(K10);
landa1=exp(K11);
eta0=sqrt((2*psi(1,1))/K20);
eta1=sqrt((2*psi(1,1))/K21);
for i=1:size(R0t,2)
P0(i)=eta0*((landa0)^eta0)*(R0t(i)^(eta0-1))/((landa0^eta0+R0t(i)^eta0)^2);
end
for i=1:size(R1t,2)
P1(i)=eta1*((landa1)^eta1)*(R1t(i)^(eta1-1))/((landa1^eta1+R1t(i)^eta1)^2);
end
n1=size(R0t,2);
n2=size(R1t,2);
p_cap0t=0;
p_cap1t=0;
for i=1:n1
p_cap0t=h(i)+p_cap0t;
end
for i=1:n2
p_cap1t=h(n1+i)+p_cap1t;
end
sigma1=0;
counter=0;
for i=1:size(R0t,2)
    counter=counter+1;
    if P0(counter)==0
        lnu=0;
    else
        lnu=log(P0(counter));
    end
    sigma1=h(counter)*lnu+sigma1;
  end
sigma2=0;
ii=0;
for i=1:size(R1t,2)
   ii=ii+1;
   counter=counter+1;
   if P1(ii)==0
        lnu=0;
    else
        lnu=log(P1(ii));
    end
   sigma2=h(counter)*(lnu)+sigma2;
end
J3=-(p_cap0t*log(p_cap0t)+p_cap1t*log(p_cap1t)+sigma1+sigma2);
end