function [J2,p0,p1]=LN_GKIT (K10,K11,K20,K21,R0t,R1t,h,u)
format long;
n1=size(R0t,2);
n2=size(R1t,2);
p_cap0t=0;
p_cap1t=0;
for i=1:n1
p_cap0t=h(i)+p_cap0t;
end
for i=1:n2
p_cap1t=h(n1+i)+p_cap1t;
end
if   p_cap0t==0
    lnP_cap0t=0;
else
    lnP_cap0t=log(p_cap0t);
end
if   p_cap1t==0
    lnP_cap1t=0;
else
    lnP_cap1t=log(p_cap1t);
end
if K20==0
    lnK20=0;
else
    lnK20=log(K20);
end
if K21==0
    lnK21=0;
else
    lnK21=log(K20);
end
  
%J2=(p_cap0t*(0.5*lnK20-lnP_cap0t)+p_cap1t*(0.5*lnK21-lnP_cap1t));
%%%%%%%%%%%%%%%%

for i=1:size(u,1)
if u(i)==0;
    lnu=0;
else
    lnu=log(u(i));
end
    p0(i)=(1/(u(i)*sqrt(2*pi*K20)))*exp(-((lnu-K10)^2)/(2*K20));
end
for i=1:size(u,1)
if u(i)==0;
    lnu=0;
else
    lnu=log(u(i));
end
    p1(i)=(1/(u(i)*sqrt(2*pi*K21)))*exp(-((lnu-K11)^2)/(2*K21));
end
sigma1=0;
for i=1:n1
   if p0(i)==0
       lnp0=0;
   else
       lnp0=log(p0(i));
   end
    sigma1=h(i)*lnp0;

end
sigma2=0;
for j=1:n2
   if p1(j)==0
       lnp1=0;
   else
       lnp1=log(p1(j));
   end
    sigma2=h(i+j)*lnp1;

end
J2=-(p_cap0t*lnP_cap0t+sigma1+p_cap1t*lnP_cap1t+sigma2);