function [K10,K20,K11,K21,R0t,R1t]=kapa(h,u,t)
format long;
 sigma1=0;sigma2=0;
 sigma3=0;sigma4=0;
  sigma5=0;sigma6=0;
 %for t=1:size(u,1)
    ii=1;jj=1;
          for i=1:t
    R0t(ii)=u(i);
    ii=ii+1;
          end
    for j=t+1:size(u,1)
       R1t(jj)=u(j);
       jj=jj+1;
       end
             for i=1:size(R0t,2);
          
          if R0t(i)==0
              lnu=0;
          else
               lnu= log(R0t(i));
          end
    sigma1=lnu*h(i)+sigma1;
    sigma2=h(i)+sigma2;
    end
            K10=sigma1/sigma2;
  for i=1:size(R0t,2);
      if R0t(i)==0
              lnu=0;
          else
               lnu= log(R0t(i));
          end
    sigma3=h(i)*(lnu-K10)^2+sigma3;
                end
      K20=sigma3/sigma2;
      %%%%%%%
          for i=1:size(R1t,2)-1;  
              if R1t(i)==0
              lnu=0;
          else
               lnu= log(R1t(i));
          end
    sigma4=(lnu)*(h(size(R0t,2)+i))+sigma4;
    sigma5=(h(size(R0t,2)+i))+sigma5;
    end
            K11=sigma4/sigma5;
            for i=1:size(R1t,2)-1;
                 if R1t(i)==0
              lnu=0;
          else
               lnu= log(R1t(i));
          end
    sigma6=(h(size(R0t,2)+i))*(lnu-K11)^2+sigma6;
                end
      K21=sigma6/sigma5;