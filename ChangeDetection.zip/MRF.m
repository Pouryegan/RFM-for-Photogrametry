function [ChangeMap_final] =MRF(R,R1,R2,R3,K10,K11,K20,K21,optimal_band_NR,optimal_band_LN,optimal_band_WR,Optml_row_NR,Optml_row_LN,Optml_row_WR )
%markov random field change detection
NR_ChangeMap=R(:,:,optimal_band_NR);
LN_ChangeMap=R2(:,:,optimal_band_LN);
WR_ChangeMap=R3(:,:,optimal_band_WR);

b_NR=optimal_band_NR;
b_LN=optimal_band_LN;
b_WR=optimal_band_WR;
for b=1:2
[P0r_NR(:,b),P1r_NR(:,b),prmtr1(b),prmtr2(b),prmtr3(b),prmtr4(b)]= NR_pdf(R1(:,:,b),K10(Optml_row_NR(b_NR),b),K11(Optml_row_NR(b_NR),b),K20(Optml_row_NR(b_NR),b),K21(Optml_row_NR(b_NR),b));
[P0r_LN(:,b),P1r_LN(:,b)]= LN_pdf(R1(:,:,b),K10(Optml_row_LN(b_LN),b),K11(Optml_row_LN(b_LN),b),K20(Optml_row_LN(b_LN),b),K21(Optml_row_LN(b_LN),b));
[P0r_WR(:,b),P1r_WR(:,b),prmtr1(b),prmtr2(b),prmtr3(b),prmtr4(b)]= WR_pdf(R1(:,:,b),K10(Optml_row_WR(b_WR),b),K11(Optml_row_WR(b_WR),b),K20(Optml_row_WR(b_WR),b),K21(Optml_row_WR(b_WR),b));
end
 alfa_NR=[1 1];
 alfa_LN=[1 1];
 alfa_WR=[1 1];
 beta_LN=1; 
 beta_NR=1; 
 beta_WR=1;
 m=1;p=0;

NR_DetectionAccuracy_DF=0;
NR_FalseAlarmRate_DF=0;
NR_OverallErrorRate_DF=0;
NR_ChangePixels_DF=0;
NR_NoChangePixels_DF=0;

LN_DetectionAccuracy_DF=0;
LN_FalseAlarmRate_DF=0;
LN_OverallErrorRate_DF=0;
LN_ChangePixels_DF=0;
LN_NoChangePixels_DF=0;

WR_DetectionAccuracy_DF=0;
WR_FalseAlarmRate_DF=0;
WR_OverallErrorRate_DF=0;
WR_ChangePixels_DF=0;
WR_NoChangePixels_DF=0;

while m <= 3 
        p=p+1;
 button=questdlg('Choose your methods','Data-Fusion with MRF','NR','LN','WR','NR');
 if button=='NR'
   alfa=alfa_NR;
   beta=beta_NR;
   ChangeMap=NR_ChangeMap;
     P0r=P0r_NR;
   P1r=P1r_NR;
   prmtr1_first=prmtr1;
   prmtr2_first=prmtr2;
   prmtr3_first=prmtr3;
   prmtr4_first=prmtr4;
  
 elseif button=='LN'
     alfa=alfa_LN;
     beta=beta_LN;
     P0r=P0r_LN;
     P1r=P1r_LN;
     ChangeMap=LN_ChangeMap;
    prmtr1_first=K10(Optml_row_LN(b_LN),:);
    prmtr2_first=K11(Optml_row_LN(b_LN),:);
    prmtr3_first=sqrt(K20(Optml_row_LN(b_LN),:));
    prmtr4_first=sqrt(K21(Optml_row_LN(b_LN),:));
     
 elseif button=='WR'
     alfa=alfa_WR;
     beta=beta_WR;
     P0r=P0r_WR;
     P1r=P1r_WR;
     ChangeMap=WR_ChangeMap;
     prmtr1_first=prmtr1;
   prmtr2_first=prmtr2;
   prmtr3_first=prmtr3;
   prmtr4_first=prmtr4;
 end
  Edge=0; 
[ChangeMap_final(:,:,m),delta_final(:,:,m),beta_final(:,:,m),alfa_final(:,:,m),Iteration_number_final(m)] = DF_MRF(0,R1,ChangeMap,alfa,beta,P0r,P1r,button,prmtr1_first,prmtr2_first,prmtr3_first,prmtr4_first);
[ DetectionAccuracy_DF,FalseAlarmRate_DF,OverallErrorRate_DF,ChangePixels_DF,NoChangePixels_DF] = Assessment_DF(ChangeMap_final(:,:,m));
if button=='NR'
NR_DetectionAccuracy_DF=DetectionAccuracy_DF;
NR_FalseAlarmRate_DF=FalseAlarmRate_DF;
NR_OverallErrorRate_DF=OverallErrorRate_DF;
NR_ChangePixels_DF=ChangePixels_DF;
NR_NoChangePixels_DF=NoChangePixels_DF;
elseif button=='LN'
LN_DetectionAccuracy_DF=DetectionAccuracy_DF;
LN_FalseAlarmRate_DF=FalseAlarmRate_DF;
LN_OverallErrorRate_DF=OverallErrorRate_DF;
LN_ChangePixels_DF=ChangePixels_DF;
LN_NoChangePixels_DF=NoChangePixels_DF;
elseif button=='WR'
WR_DetectionAccuracy_DF=DetectionAccuracy_DF;
WR_FalseAlarmRate_DF=FalseAlarmRate_DF;
WR_OverallErrorRate_DF=OverallErrorRate_DF;
WR_ChangePixels_DF=ChangePixels_DF;
WR_NoChangePixels_DF=NoChangePixels_DF;
end
  figure('Name','Data-Fusion Markov Random Field','Position',[640 40 600 500]);
   hold off;
      for j=1:m
          hold off;
   subplot(1,m,j)
   imshow(ChangeMap_final(:,:,j));
      end
      
     m=m+1;
     if m<4
     button2=questdlg('Do You want to test another methods?','Data-Fusion','Yes','No','Yes');
     button_rslt=strcmp(button2,'No');
     if button_rslt==1
                   m=4;
     end
     end
end
figure('Name','Data-Fusion Assessment','Position',[40 515 680 100]);
columnname ={'Methods','Change pixels','No change pixels','Detection Accuracy','false-alarm rate','overall error rate'};
columnformat = {'char', 'numeric','numeric', 'numeric','numeric','numeric','numeric'}; 
dat2 ={'NR',NR_ChangePixels_DF,NR_NoChangePixels_DF,100*NR_DetectionAccuracy_DF,100*NR_FalseAlarmRate_DF,100*NR_OverallErrorRate_DF;...
         'LN',LN_ChangePixels_DF,LN_NoChangePixels_DF,100*LN_DetectionAccuracy_DF,100*LN_FalseAlarmRate_DF,100*LN_OverallErrorRate_DF;...   
         'WR',WR_ChangePixels_DF,WR_NoChangePixels_DF,100*WR_DetectionAccuracy_DF,100*WR_FalseAlarmRate_DF,100*WR_OverallErrorRate_DF;};
t3= uitable('Units','normalized','Position',...
            [0.1 0.1 0.9 0.9], 'Data', dat2,... 
            'ColumnName', columnname,...
            'ColumnFormat', columnformat);
end
%%%%%