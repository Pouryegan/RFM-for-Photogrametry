function [ DetectionAccuracy,FalseAlarmRate,OverallErrorRate,ChangePixels,NoChangePixels] = Assessment_DF(ChangeMap)
n1=size(ChangeMap,1);
n2=size(ChangeMap,2);
n=n1*n2;
AllNoChangeTestPixels=99*(n2-91);
AllChangeTestPixels=n-AllNoChangeTestPixels;
ChangePixels=0;
for i=1:n
   if ChangeMap(i)==1
       ChangePixels=ChangePixels+1;
      end
end
NoChangePixels=n-ChangePixels;
DetectionAccuracy=ChangePixels/AllChangeTestPixels;
FalseAlarmRate=(NoChangePixels-AllNoChangeTestPixels)/AllChangeTestPixels;
erroneosslyLabeldTestPixels=NoChangePixels-AllNoChangeTestPixels;
for i=1:99
    for j=91:n2
       if ChangeMap(i,j)==1
       erroneosslyLabeldTestPixels=erroneosslyLabeldTestPixels+1; 
       end
    end
end
OverallErrorRate=erroneosslyLabeldTestPixels/n;
end


