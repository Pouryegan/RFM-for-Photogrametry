function [ ChangeMap,delta,beta,alfa,Iteration_number,U_H0,U_H1,M_H0,M_H1 ] = DF_MRF(Edge,R1,ChangeMap,alfa,beta,P0r,P1r,button,prmtr1_first,prmtr2_first,prmtr3_first,prmtr4_first)

n=size(ChangeMap,1)*size(ChangeMap,2);
Iteration_number=0;
 delta1=ones(1,2);
threshold=ones(1,2)*0.001;
 allow=1;
while delta1 > threshold
%for tekrar=1:16
     Iteration_number=Iteration_number+1
       for b=1:2
 alfa_first(b)=alfa(b);
     end
      beta_first=beta;
     [M_H0,M_H1]=Mik(ChangeMap);
    if Edge==1
    %  [U0_E,U1_E] = EdgeEnergy(ChangeMap,R1);
       [EdgeMap] = Edge(R1);
        [E0,E1]=Mik(EdgeMap);
         for i=1:n
             if ChangeMap(i)==0
U_H0(i)=alfa(1)*(-log(P0r(i,1)))+alfa(2)*(-log(P0r(i,2)))-beta*M_H0(i)-(E0(i));
U_H1(i)=alfa(1)*(-log(P0r(i,1)))+alfa(2)*(-log(P0r(i,2)))-beta*M_H1(i)-(E1(i));
  end
         end
   else
  for i=1:n
U_H0(i)=alfa(1)*(-log(P0r(i,1)))+alfa(2)*(-log(P0r(i,2)))-beta*M_H0(i);
U_H1(i)=alfa(1)*(-log(P0r(i,1)))+alfa(2)*(-log(P0r(i,2)))-beta*M_H1(i);
 end
   end
  %COMPUTING PROPABALITY OF PIXELS IN THREE METHODS
   P_L_H0=zeros(1,n);
   P_L_H1=zeros(1,n);
for i=1:n
   if ChangeMap(i)==0
    P_L_H0(i)=(exp(-U_H0(i)))/(exp(-U_H0(i))+exp(-U_H1(i)));
   elseif ChangeMap(i)==1
    P_L_H1(i)=(exp(-U_H1(i)))/(exp(-U_H0(i))+exp(-U_H1(i)));
         end
  end
           %%%%%%%update labels
           ChangeMapFirst=ChangeMap;
for i=1:n
    if ChangeMap(i)==0
       min_H=min(U_H0(i),U_H1(i));
       if min_H==U_H0(i)
           ChangeMap(i)=0;
       elseif min_H==U_H1(i) 
           ChangeMap(i)=1;
       end
    end
end
  
%step 3 computing K1ir,K2ir
W0k=P_L_H0;
W1k=P_L_H1;

for b=1:2
sigma1_=0;
sigma2_=0;
sigma3_=0;
sigma4_=0;
sigma5_=0;
sigma6_=0;
 R0=R1(:,:,b);
for i=1:n
sigma1_=sigma1_+W0k(i)*log(R0(i));
sigma2_=sigma2_+W0k(i);
sigma3_=sigma3_+W1k(i)*log(R0(i));
sigma4_=sigma4_+W1k(i);

end
K10(b)=sigma1_/sigma2_;
K11(b)=sigma3_/sigma4_;
    %end
   % end
%K2ir   
%for b=1:2
 %   if delta(3,b)>0.001 ||delta(4,b)>0.001
for i=1:n
sigma5_=sigma5_+W0k(i)*((log(R0(i))-K10(b))^2);
sigma6_=sigma6_+W1k(i)*((log(R0(i))-K11(b))^2);
end
K20(b)=sigma5_/sigma2_;
K21(b)=sigma6_/sigma4_;
end
%end
%end
%%%%%%Beta
if allow==1
    allow==0;
i_=0;
for beta=0.1:0.1:10
    i_=i_+1;
beta_all(i_,1)=0;

    for j=1:n
beta_all(i_,1)=beta*(W0k(j)*M_H0(j)+W1k(j)*M_H1(j))-log(exp(beta*(M_H0(j)+M_H1(j))))+beta_all(i_,1);
beta_all(i_,2)=beta;
        end
end
  B=max(beta_all(:,1));  
  for j=1:i_
     if beta_all(j,1)==B
         Beta=beta_all(j,2);
     end
          
  end
end
%%%%%
        diffBeta=1;
         while diffBeta>0.001
          Beta1=Beta; 
          Phi_prim_Beta=0;
          Phi_prim_Beta2=0;
          for i_=1:n
              Phi_prim_Beta=W0k(i_)*M_H0(i_)+W1k(i_)*M_H1(i_)-(M_H0(i_)*exp(Beta*M_H0(i_))+M_H1(i_)*exp(Beta*M_H1(i_)))/(exp(Beta*M_H0(i_))+exp(Beta*M_H1(i_)))+Phi_prim_Beta;
              Phi_prim_Beta2=W0k(i_)*M_H0(i_)+W1k(i_)*M_H1(i_)-(M_H0(i_)*exp((Beta+0.0001)*M_H0(i_))+M_H1(i_)*exp((Beta+0.0001)*M_H1(i_)))/(exp((Beta+0.0001)*M_H1(i_))+exp((Beta+0.0001)*M_H1(i_)))+Phi_prim_Beta2;
          end
          Beta=Beta1-Phi_prim_Beta/((Phi_prim_Beta-Phi_prim_Beta2)/0.0001);
            diffBeta=abs(Beta-Beta1);
        end
        beta=Beta;

  for b=1:2
      
      if button=='NR'
[P0r(:,b),P1r(:,b),prmtr1(b),prmtr2(b),prmtr3(b),prmtr4(b)]= NR_pdf(R1(:,:,b),K10(b),K11(b),K20(b),K21(b));

      elseif button=='LN'
[P0r(:,b),P1r(:,b),prmtr1(b),prmtr2(b),prmtr3(b),prmtr4(b)]= LN_pdf(R1(:,:,b),K10(b),K11(b),K20(b),K21(b));
  
      elseif button=='WR'
[P0r(:,b),P1r(:,b),prmtr1(b),prmtr2(b),prmtr3(b),prmtr4(b)]= WR_pdf(R1(:,:,b),K10(b),K11(b),K20(b),K21(b));
      end
end
  %step5 ALFA

  Cr=zeros(1,2);
  q=2;
  q_=q/(q-1);
  for b=1:2
            for k=1:n
  Cr(b)=W0k(k)*log(P0r(k,b))+W1k(k)*log(P1r(k,b))+Cr(b);
            end 
  end
   C_q_norm=((abs(Cr(1)))^q_+(abs(Cr(2)))^q_)^(1/q_);
     for b=1:2
         
      C(b)=Cr(b)/C_q_norm;
           if C_q_norm==0
          C(b)=0;
      end
      alfa(b)=0.5+0.5*(C(b))^(1/(q-1));
         end

  for b=1:2
     delta(1,b)=abs(prmtr1_first(b)-prmtr1(b));
     delta(2,b)=abs(prmtr2_first(b)-prmtr2(b));
     delta(3,b)=abs(prmtr3_first(b)-prmtr3(b));
     delta(4,b)=abs(prmtr4_first(b)-prmtr4(b));
    
       prmtr1_first(b)=prmtr1(b);
       prmtr2_first(b)=prmtr2(b);
      prmtr3_first(b)=prmtr3(b);
     prmtr4_first(b)=prmtr4(b);
     
 delta(5,b)=abs(alfa_first(b)-alfa(b));
 delta(6,b)=abs(beta_first-beta); 

  end
delta1=(max(delta));
if ChangeMap==ones(size(ChangeMap,1),size(ChangeMap,2))
    ChangeMap=ChangeMapFirst;
    Iteration_number_final=Iteration_number-1;
disp(Iteration_number_final);
end
end


