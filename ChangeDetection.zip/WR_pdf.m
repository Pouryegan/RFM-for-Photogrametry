function [ P0,P1,landa0,landa1,eta0,eta1 ] = WR_pdf(R,K10,K11,K20,K21)
format long;
n=size(R,1)*size(R,2);
landa0=exp(K10);
landa1=exp(K11);
eta0=sqrt((2*psi(1,1))/K20);
eta1=sqrt((2*psi(1,1))/K21);
for i=1:n
P0(i)=eta0*((landa0)^eta0)*(R(i)^(eta0-1))/((landa0^eta0+R(i)^eta0)^2);
P1(i)=eta1*((landa1)^eta1)*(R(i)^(eta1-1))/((landa1^eta1+R(i)^eta1)^2);
end