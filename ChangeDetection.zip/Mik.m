function [H0,H1] = Mik(R)
H0=zeros(size(R,1),size(R,2));
H1=zeros(size(R,1),size(R,2));
n1=size(R,1);
n2=size(R,2);
  for i=2:n1-1
      for j=2:n2-1
     H0(i,j)=8-(R(i,j-1)+R(i,j+1)+R(i-1,j)+R(i+1,j)+R(i-1,j-1)+R(i+1,j+1));
     H1(i,j)=R(i,j-1)+R(i,j+1)+R(i-1,j)+R(i+1,j)+R(i-1,j-1)+R(i+1,j+1);
   end
      end

%%edges
for i=2:n1-1
    for j=1
     H0(i,j)=5-(R(i-1,j)+R(i-1,j+1)+R(i,j+1)+R(i+1,j+1)+R(i+1,j));
     H1(i,j)=R(i-1,j)+R(i-1,j+1)+R(i,j+1)+R(i+1,j+1)+R(i+1,j);
    end
      for j=n2
     H0(i,j)=5-(R(i-1,j)+R(i-1,j-1)+R(i,j-1)+R(i+1,j-1)+R(i+1,j));
     H1(i,j)=(R(i-1,j)+R(i-1,j-1)+R(i,j-1)+R(i+1,j-1)+R(i+1,j));
         end
end

    for j=2:n2-1
        for i=1
     H0(i,j)=5-(R(i,j-1)+R(i+1,j-1)+R(i+1,j)+R(i+1,j+1)+R(i,j+1));
     H1(i,j)=R(i,j-1)+R(i+1,j-1)+R(i+1,j)+R(i+1,j+1)+R(i,j+1);
    end
      for i=n1
     H0(i,j)=5-(R(i,j-1)+R(i-1,j-1)+R(i-1,j)+R(i-1,j+1)+R(i,j+1));
     H1(i,j)=(R(i,j-1)+R(i-1,j-1)+R(i-1,j)+R(i-1,j+1)+R(i,j+1));
         end
    end

    for i=1
        for j=1
           H0(i,j)=3-(R(i,j+1)+R(i+1,j+1)+R(i+1,j));
     H1(i,j)=R(i,j+1)+R(i+1,j+1)+R(i+1,j);  
                          
        end
    end
       for i=1
        for j=n2
           H0(i,j)=3-(R(i,j-1)+R(i+1,j-1)+R(i+1,j));
     H1(i,j)=(R(i,j-1)+R(i+1,j-1)+R(i+1,j));  
                          
        end
    end
           for i=n1
        for j=1
           H0(i,j)=3-(R(i-1,j)+R(i-1,j+1)+R(i,j+1));
     H1(i,j)=(R(i-1,j)+R(i-1,j+1)+R(i,j+1));  
                          
        end
           end
    
                      for i=n1
        for j=n2
           H0(i,j)=3-(R(i,j-1)+R(i-1,j-1)+R(i,j));
     H1(i,j)=(R(i,j-1)+R(i-1,j-1)+R(i,j));  
                          
        end
    end
           
     end      
           