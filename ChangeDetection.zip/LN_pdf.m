function [ P0,P1,prmtr1,prmtr2,prmtr3,prmtr4] =LN_pdf(R,K10,K11,K20,K21 )
format long;
n=size(R,1)*size(R,2);

 for i=1:n

    P0(i)=(1/(R(i)*sqrt(2*pi*K20)))*exp(-((log(R(i))-K10)^2)/(2*K20));
    P1(i)=(1/(R(i)*sqrt(2*pi*K21)))*exp(-((log(R(i))-K11)^2)/(2*K21));
 end
   prmtr1=K10;
   prmtr2=K11;
   prmtr3=sqrt(K20);
   prmtr4=sqrt(K21);
end