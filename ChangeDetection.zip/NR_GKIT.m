function [J,P0,P1]= NR_GKIT(K10,K11,K20,K21,R0t,R1t,h)
format long;
prmtr0=exp(2*K10);
prmtr1=exp(2*K11);
counter=1;L0=-1;L1=-1;
for i=0:0.1:100
    out1=psi(1,i)/2;
 delta0(counter)=abs(out1-K20);
 delta1(counter)=abs(out1-K21);
  if delta0(counter) <=0.01
    L0=i;    
  end
   if delta1(counter) <=0.01
    L1=i;
   end 
  if delta1(counter)<=0.1 && delta0(counter) <=0.01
      break;
  end
  counter=counter+1;
end
if L0==-1
for i=1:length(delta0)
          if delta0(i)==min(delta0);
              L0=(i-1)*0.1;
          end
end
end
if L1==-1
for i=1:length(delta1)
          if delta1(i)==min(delta1);
              L1=(i-1)*0.1;
          end
end
end
%%%%%
u1=R0t;
u2=R1t;
p_cap0t=sum(u1);
p_cap1t=sum(u2);
i1=0;i2=0;
for i=1:size(u1,2)
    i1=i1+1;
P0(i1)=(2*gamma(2*L0)*(prmtr0^L0)*(u1(i)^(2*L0-1)))/((gamma(L0))^2*(prmtr0+u1(i)^2)^(2*L0));
end
for i=1:size(u2,2)
    i2=i2+1;
P1(i2)=(2*gamma(2*L1)*(prmtr1^L1)*(u2(i)^(2*L1-1)))/((gamma(L1))^2*(prmtr1+u2(i)^2)^(2*L1));
end
sigma1=0;counter=0;
for i=1:size(u1,2)
    counter=counter+1;
    if P0(counter)==0
        lnu=0;
    else
        lnu=log(P0(counter));
    end
    sigma1=h(counter)*lnu+sigma1;
  end
sigma2=0;ii=0;
for i=1:size(u2,2)
    counter=counter+1;ii=ii+1;
    if P1(ii)==0
        lnu=0;
    else
        lnu=log(P1(ii));
    end
    sigma2=h(counter)*lnu+sigma2;
end
J=-(p_cap0t*log(p_cap0t)+p_cap1t*log(p_cap1t)+sigma1+sigma2);