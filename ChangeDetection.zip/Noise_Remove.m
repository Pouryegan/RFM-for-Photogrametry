function [f,deltaSigma] = Noise_Remove(ChangeMap)
n1=size(ChangeMap,1);
n2=size(ChangeMap,2);
d=ChangeMap;
n=n1*n2;
sigma=1;
%f=ChangeMap;
f=ones(n1,n2);
for i=1:99
    for j=91:179
        f(i,j)=0;
              
    end
end
for i=150:160
    for j=50:90
        f(i,j)=0;
              
    end
end
tekrar=0;
deltaSigma=1;
while deltaSigma>0.001
    sigma1=sigma;
    tekrar=tekrar+1
for i=1:n1
  for j=1:n2
 [delta]= deltaF_Ni(f,i,j);
priorEnergy0=0;
priorEnergy1=0;
if f(i,j)==0
   priorEnergy0=(f(i,j)-d(i,j))^2/(2*sigma)+(1-delta);
   f(i,j)=1;
 priorEnergy1=(f(i,j)-d(i,j))^2/(2*sigma)+(1-delta);  
   minEnergy=min(priorEnergy0,priorEnergy1);
  if minEnergy==priorEnergy0
      f(i,j)=0;
  else
    f(i,j)=1;   
  end
end
 sigma=0;
 for ii=1:n
    sigma=(f(ii)-d(ii))^2+sigma; 
 end
 sigma=sigma/n;
  end
  sigma2=sigma;
end
deltaSigma=abs(sigma2-sigma1);
    end


