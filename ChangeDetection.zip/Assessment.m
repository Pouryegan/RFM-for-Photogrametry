function [ DetectionAccuracy,FalseAlarmRate,OverallErrorRate] = Assessment(R,NoChangePixels,ChangePixels)
n1=size(R,1);
n2=size(R,2);
n=n1*n2;
AllNoChangeTestPixels=99*(n2-91);
AllChangeTestPixels=n-AllNoChangeTestPixels;
DetectionAccuracy=ChangePixels/AllChangeTestPixels;
FalseAlarmRate=(NoChangePixels-AllNoChangeTestPixels)/AllChangeTestPixels;
erroneosslyLabeldTestPixels=NoChangePixels-AllNoChangeTestPixels;
for i=1:99
    for j=91:n2
       if R(i,j)==1
       erroneosslyLabeldTestPixels=erroneosslyLabeldTestPixels+1; 
       end
    end
end
OverallErrorRate=erroneosslyLabeldTestPixels/n;
end


