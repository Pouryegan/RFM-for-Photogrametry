function [P0,P1,prmtr0,prmtr1,L0,L1] = NR_pdf(R,K10,K11,K20,K21)
format long;
prmtr0=exp(2*K10);
prmtr1=exp(2*K11);
counter=1;L0=-1;L1=-1;
for i=0:0.01:100
    out1=psi(1,i)/2;
 delta0(counter)=abs(out1-K20);
 delta1(counter)=abs(out1-K21);
  if delta0(counter) <=0.001
    L0=i;    
  end
   if delta1(counter) <=0.001
    L1=i;
   end 
  if delta1(counter)<=0.001 && delta0(counter) <=0.001
      break;
  end
  counter=counter+1;
end
if L0==-1
for i=1:length(delta0)
          if delta0(i)==min(delta0);
              L0=(i-1)*0.1;
          end
end
end
if L1==-1
for i=1:length(delta1)
          if delta1(i)==min(delta1);
              L1=(i-1)*0.1;
          end
end
end
%%%%%
n=size(R,1)*size(R,2);
for i=1:n 
P0(i)=(2*gamma(2*L0)*(prmtr0^L0)*(R(i)^(2*L0-1)))/((gamma(L0))^2*(prmtr0+R(i)^2)^(2*L0));
P1(i)=(2*gamma(2*L1)*(prmtr1^L1)*(R(i)^(2*L1-1)))/((gamma(L1))^2*(prmtr1+R(i)^2)^(2*L1));
end