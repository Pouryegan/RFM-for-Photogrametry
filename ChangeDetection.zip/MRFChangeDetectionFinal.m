clear
clc
format long;
HH=load('HH.txt');
HV=load('HV.txt');
button1=questdlg('Do You want to use sigma..?','Filtering','yes','no','yes');
question=strcmp(button1,'yes');
Z0(:,:,1)=HH;
Z0(:,:,2)=HV;
Z1=Z0;
n1=size(Z0,1);
n2=size(Z0,2);
n=n1*n2;
for b=1:2
for i=1:99
    for j=1:45
        
        if Z1(i,j,b)>=41
            Z1(i,j,b)=Z1(i,j,b)-40;
        else
           Z1(i,j,b)=Z1(i,j,b)+30;         
        end
    end
    for j=45:90
     Z1(i,j,b)=Z1(i,j,b)-200;
    end
end

for i=100:198
    for j=1:90
        Z1(i,j,b)=Z1(i,j,b)+100;
    end
    for j=91:179
        Z1(i,j,b)=Z1(i,j,b)+500;
    end
end
end

if question==1
    for b=1:2
for i=1:n1
    for j=1:n2
    Z0(i,j,b)=((Z0(i,j,b)^2)/430526.59375)*sin((24.3506/180)*pi);
        if Z0(i,j,b)==0
            Z0(i,j,b)=0.0001;
        end
    Z1(i,j,b)=((Z1(i,j,b)^2)/430526.59375)*sin((24.3506/180)*pi);
        if Z1(i,j,b)==0
            Z1(i,j,b)=0.0001;
        end   
    end
end
    end
end
   RR1=zeros(n1,n2);
   RR2=zeros(n1,n2);
   band=2; 
count=zeros(1,band);
for b=1:band
for i=1:n1
    for j=1:n2
        RR1(i,j,b)=Z0(i,j,b)/Z1(i,j,b);
        RR2(i,j,b)=Z1(i,j,b)/Z0(i,j,b);
        R(i,j,b)=min(RR1(i,j,b),RR2(i,j,b));
        end
end
end

R1=R;
R2=R;
R3=R;
maxR=zeros(1,band);
minR=ones(1,band);
for b=1:band
    for i=1:size(R,1)
        for j=1:size(R,2)
          maxR(b)=max(R(i,j,b),maxR(b));
minR(b)=min(R(i,j,b),minR(b));
                    end
    end
end

figure('Name','Histograms','Position',[760 160 600 500])
title('Normalized Histogram')
subplot(231)
hist(Z0(:,:,1));
title('HH t1')
xlabel('u')
ylabel('h(u)')
subplot(232)
hist(Z1(:,:,1))
title('HH t2')
xlabel('u')
ylabel('h(u)')
subplot(233)
hist(Z0(:,:,2));
title('HV t1')
xlabel('u')
ylabel('h(u)')
subplot(234)
hist(Z1(:,:,2))
title('HV t2')
xlabel('u')
ylabel('h(u)')
subplot(235)
%normalized histogeram
x1=minR(1):0.01:maxR(1);
hist(R(:,:,1),x1);
title('Ratio Image')
xlabel('u')
ylabel('h(u)')
[H(:,:,1),z(:,1)]=hist(R(:,:,1),x1);
subplot(236);
x2=minR(2):0.01:maxR(2);
hist(R(:,:,2),x2);
[H(:,:,2),z(:,2)]=hist(R(:,:,2),x2);
hold off
%%%%%%%%%%%
for i=1:size(H,1)
    h(i,1)=sum(H(i,:,1));
     h(i,2)=sum(H(i,:,2));
end

for b=1:2
   tt=0; 
for t1=1:size(z,1)-1
    t=z(t1,b);
    tt=tt+1;
[K10(tt,b),K20(tt,b),K11(tt,b),K21(tt,b),R0t,R1t]=kapa(h(:,b),z(:,b),t1);
[J(tt,1,b),P0_NR,P1_NR]=NR_GKIT(K10(tt,b),K11(tt,b),K20(tt,b),K21(tt,b),R0t,R1t,h(:,b));
[J2(tt,1,b),P0_LN,P1_LN]=LN_GKIT(K10(tt,b),K11(tt,b),K20(tt,b),K21(tt,b),R0t,R1t,h(:,b),z(:,b));
[J3(tt,1,b),eta0(tt,b),eta1(tt,b),p_cap0t(tt,b),p_cap1t(tt,b),sigma1(tt,b),sigma2(tt,b),P0_WR,P1_WR]=WR_GKIT(K10(tt,b),K11(tt,b),K20(tt,b),K21(tt,b),R0t,R1t,h(:,b));
J(tt,2,b)=t;
J2(tt,2,b)=t;
J3(tt,2,b)=t;
end
end

for b=1:2
for i=1:size(J,1)
    if J(i,1,b)==-Inf
        J(i,1,b)=Inf;
    end
        if J2(i,1,b)==-Inf
        J2(i,1,b)=Inf;
    end
    if J3(i,1,b)==-Inf
        J3(i,1,b)=Inf;
    end
end
end

for b=1:2
for t=1:size(J,1)
    if J(t,1,b)==min(J(:,1,b));
        NR_Optml_trshld(b)=J(t,2,b);
        Optml_row_NR(b)=t;
        break;
    end
end
for t=1:size(J2,1)
    if J2(t,1,b)==min(J2(:,1,b));
       LN_Optml_trshld(b)=J2(t,2,b); 
       Optml_row_LN(b)=t;
       break;
    end
end
for t=1:size(J3,1)
     if J3(t,1,b)==min(J3(:,1,b));
       WR_Optml_trshld(b)=J3(t,2,b);
       Optml_row_WR(b)=t;
       break;
    end
end
end

NR_change=zeros(1,2);
LN_change=zeros(1,2);
WR_change=zeros(1,2);
for b=1:2
for i=1:size(R,1)
    for j=1:size(R,2)
        if R(i,j,b)< NR_Optml_trshld(b)
            R(i,j,b)=1;
            NR_change(b)=NR_change(b)+1;
        else
 R(i,j,b)=0;
        end
        if R2(i,j,b)< LN_Optml_trshld(b)
            R2(i,j,b)=1;
            LN_change(b)=LN_change(b)+1;
        else
 R2(i,j,b)=0;
        end 
        if R3(i,j,b)< WR_Optml_trshld(b)
            R3(i,j,b)=1;
            WR_change(b)=WR_change(b)+1;
        else
 R3(i,j,b)=0;
        end 
    end
end
end

for b=1:2
NR_no_change(b)=(size(R,1))*(size(R,2))-NR_change(b);
LN_no_change(b)=(size(R,1))*(size(R,2))-LN_change(b);
WR_no_change(b)=(size(R,1))*(size(R,2))-WR_change(b);
end

figure('Name','Change Detection HH','Position',[730 130 600 500])
subplot(231);
%imshow(HH);
title('First Image')
subplot(232);
%imshow(Z1);
title('Second Image')
subplot(233);
imshow(R(:,:,1));
title('Nakagami-Ratio GKIT')
subplot(234);
imshow(R2(:,:,1));
title('Log-Normal GKIT')
subplot(235);
imshow(R3(:,:,1));
title('Weibull-Ratio GKIT')
figure('Name','Change Detection HV','Position',[700 100 600 500])
subplot(231);
%imshow(HH);
title('First Image')
subplot(232);
%imshow(Z1);
title('Second Image')
subplot(233);
imshow(R(:,:,2));
title('Nakagami-Ratio GKIT')
subplot(234);
imshow(R2(:,:,2));
title('Log-Normal GKIT')
subplot(235);
imshow(R3(:,:,2));
title('Weibull-Ratio GKIT')
%%%
for b=1:2
[ NR_DetectionAccuracy(b),NR_FalseAlarmRate(b),NR_OverallErrorRate(b)] = Assessment(R,NR_no_change(b),NR_change(b));
[ LN_DetectionAccuracy(b),LN_FalseAlarmRate(b),LN_OverallErrorRate(b)] = Assessment(R2,LN_no_change(b),LN_change(b));
[ WR_DetectionAccuracy(b),WR_FalseAlarmRate(b),WR_OverallErrorRate(b)] = Assessment(R3,WR_no_change(b),WR_change(b));
end
%%%
f = figure('Position',[0 530 680 150],'Name','Results');
dat =  {'NR',NR_Optml_trshld(1),NR_change(1),NR_no_change(1),100*NR_DetectionAccuracy(1),100*NR_FalseAlarmRate(1),100*NR_OverallErrorRate(1);...
        'LN',LN_Optml_trshld(1),LN_change(1),LN_no_change(1),100*LN_DetectionAccuracy(1),100*LN_FalseAlarmRate(1),100*LN_OverallErrorRate(1);...   
        'WR',WR_Optml_trshld(1),WR_change(1),WR_no_change(1),100*WR_DetectionAccuracy(1),100*WR_FalseAlarmRate(1),100*WR_OverallErrorRate(1);...
        'NR',NR_Optml_trshld(2),NR_change(2),NR_no_change(2),100*NR_DetectionAccuracy(2),100*NR_FalseAlarmRate(2),100*NR_OverallErrorRate(2);...
        'LN',LN_Optml_trshld(2),LN_change(2),LN_no_change(2),100*LN_DetectionAccuracy(2),100*LN_FalseAlarmRate(2),100*LN_OverallErrorRate(2);...   
        'WR',WR_Optml_trshld(2),WR_change(2),WR_no_change(2),100*WR_DetectionAccuracy(2),100*WR_FalseAlarmRate(2),100*WR_OverallErrorRate(2);};
columnname =   {'Methods', 'Optimol treshold', 'Change pixels', 'No change pixels','Detection Accuracy','false-alarm rate','overall error rate'};
columnformat = {'char', 'numeric','numeric', 'numeric','numeric','numeric','numeric'}; 
columneditable =  [false false true true]; 
t = uitable('Units','normalized','Position',...
            [0.1 0.1 0.9 0.9], 'Data', dat,... 
            'ColumnName', columnname,...
            'ColumnFormat', columnformat,...
            'ColumnEditable', columneditable);
%%%%%%%%%%%%%%%%%%%%%%%%%%%
 mJ=min(J(Optml_row_NR,2,1),J(Optml_row_NR,2,2));
if mJ==J(Optml_row_NR,2,1)
    optimal_thrshld_NR=NR_Optml_trshld(1);
    optimal_band_NR=1;
else
    optimal_thrshld_NR=NR_Optml_trshld(2);
    optimal_band_NR=2;
end
mJ2=min(J2(Optml_row_LN,2,1),J2(Optml_row_LN,2,2));
 if mJ2==J2(Optml_row_LN,2,1)
    optimal_thrshld_LN=LN_Optml_trshld(1);
     optimal_band_LN=1;
else
    optimal_thrshld_LN=LN_Optml_trshld(2);
     optimal_band_LN=2;
end 
 mJ3=min(J3(Optml_row_WR,2,1),J3(Optml_row_WR,2,2));
 if mJ3==J3(Optml_row_WR,2,1)
    optimal_thrshld_WR=WR_Optml_trshld(1);
     optimal_band_WR=1;
else
    optimal_thrshld_WR=WR_Optml_trshld(2);
     optimal_band_WR=2;
 end 
  %optimal change detection
f1 = figure('Position',[20 525 680 100],'Name','Optimal Results');
dat1 =  { 'NR',optimal_thrshld_NR,NR_change(optimal_band_NR),NR_no_change(optimal_band_NR),100*NR_DetectionAccuracy(optimal_band_NR),100*NR_FalseAlarmRate(optimal_band_NR),100*NR_OverallErrorRate(optimal_band_NR);...
        'LN',optimal_thrshld_LN,LN_change(optimal_band_LN),LN_no_change(optimal_band_LN),100*LN_DetectionAccuracy(optimal_band_LN),100*LN_FalseAlarmRate(optimal_band_LN),100*LN_OverallErrorRate(optimal_band_LN);...   
        'WR',optimal_thrshld_WR,WR_change(optimal_band_WR),WR_no_change(optimal_band_WR),100*WR_DetectionAccuracy(optimal_band_WR),100*WR_FalseAlarmRate(optimal_band_WR),100*WR_OverallErrorRate(optimal_band_WR);};

t2 = uitable('Units','normalized','Position',...
            [0.1 0.1 0.9 0.9], 'Data', dat1,... 
            'ColumnName', columnname,...
            'ColumnFormat', columnformat,...
            'ColumnEditable', columneditable);
%%%%%%%%%%%%%%%%%
figure('Name',' Optimal Change Detection','Position',[670 70 600 500])
subplot(131)
imshow(R(:,:,optimal_band_NR));
title('Nakagami Ratio')
subplot(132)
imshow(R2(:,:,optimal_band_LN));
title('Log-normal')
subplot(133)
imshow(R3(:,:,optimal_band_WR));
title('Weibull Ratio')
%%%%%%%%%%%%%%%%%%%%%%MRF
[ChangeMapMRF]=MRF(R,R1,R2,R3,K10,K11,K20,K21,optimal_band_NR,optimal_band_LN,optimal_band_WR,Optml_row_NR,Optml_row_LN,Optml_row_WR);
%%%%%%%%%%%%%%%%%%%%%%Edge
button3=questdlg('Do You want to test with edge information?','DF with Edge labeling','Yes','No','Yes');
button_rslt=strcmp(button3,'Yes');
if button_rslt==1
 [EdgeMap] = Edge(R1(:,:,1));   
[ChangeMapEdge]=MRF_Edge(EdgeMap,ChangeMapMRF,R,R1,R2,R3,K10,K11,K20,K21,optimal_band_NR,optimal_band_LN,optimal_band_WR,Optml_row_NR,Optml_row_LN,Optml_row_WR);    
end



  